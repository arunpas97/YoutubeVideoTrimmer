class YoutubeVideoTrimmer:
    def __init__(self):
        print("YoutubeVideoTrimmer is under development")