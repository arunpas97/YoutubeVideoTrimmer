class link:
    def __init__(self):
        return "YoutubeVideoTrimmer"