class YoutubeVideoTrimmer:
    def __init__(self):
        print("Youtube Video Trimmer")