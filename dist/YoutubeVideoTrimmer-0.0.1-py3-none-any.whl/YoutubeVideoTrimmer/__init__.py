def link():
    print("Hello World")